# Reglas del proyecto: El río de los impuestos

Sitio de divulgación sobre la historia fiscal de México (1428-2026). Todo el texto visible va en español de México.

## Cómo está armado

- La página es **estática** y vive en `public/`: `index.html`, `css/rio.css`, `js/rio.js` (JavaScript sin frameworks), `datos/` y `fuentes/`.
- Next.js solo la sirve: `next.config.mjs` reescribe `/` a `/index.html`. `app/layout.js` existe porque Next.js lo exige; no hay `app/page.js` a propósito.
- Un año concreto se abre con `/#1790` o `/?anio=1790`; eso debe seguir funcionando.

## Lo que no se toca a mano

- `public/datos/rio.json` y `public/datos/rio.datos.js` se generan con `exportar_sitio.py` desde el libro de investigación `Impuestos_historicos_Mexico_v0.2.xlsx`. No edites ni inventes obligaciones, fechas, tasas, fuentes ni textos de las fichas: cualquier cambio de contenido se hace en el libro y se vuelve a exportar.
- Las reglas de conteo (tramo firme, tramo blando, fin no documentado hasta el sucesor o 30 años) están en `js/rio.js` y deben coincidir con las del libro.

## Diseño y accesibilidad

- Tema oscuro único con los tokens del sistema Platzi Sinapsis definidos en `css/rio.css` (`--sin-*`). Usa esos tokens; no agregues colores sueltos.
- Tipografías locales en `public/fuentes/` (Bricolage Grotesque, Plus Jakarta Sans, IBM Plex Mono). No cargues fuentes externas.
- Conserva: deslizador con teclado, botones de familia con `aria-pressed`, anuncio del año con `aria-live`, la tabla "Todos los datos", el modo celular (el río corre hacia abajo) y `prefers-reduced-motion`.
- El grosor del río cuenta obligaciones vigentes; no mide recaudación. No agregues textos que sugieran lo contrario.

<!-- BEGIN:nextjs-agent-rules -->

## This is NOT the Next.js you know

This version has breaking changes — APIs, conventions, and file structure may all differ from your training data. Read the relevant guide in `node_modules/next/dist/docs/` (resolved from this file's directory; in monorepos the `next` package may not be visible from the repo root) before writing any code. Heed deprecation notices.

This block is written and re-added by `next dev` — verify at `node_modules/next/dist/server/lib/generate-agent-files.js`. Removing it from a diff only re-creates the uncommitted change; committing it with your work keeps the tree clean.

<!-- END:nextjs-agent-rules -->
