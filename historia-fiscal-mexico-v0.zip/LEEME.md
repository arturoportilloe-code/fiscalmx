# El río de los impuestos — paquete para v0

Versión 0.2 del sitio (corte: 30 de octubre de 2026; 109 versiones de impuestos, 50 fuentes), lista para importarse en v0 de Vercel.

## Estructura

| Ruta | Contenido |
|---|---|
| `public/index.html` | La página del río |
| `public/css/rio.css` | Estilos y tokens de color (Platzi Sinapsis, tema oscuro) |
| `public/js/rio.js` | Cálculo y dibujo del río, recorrido, lectura del año, tabla |
| `public/datos/rio.json` | Contrato de datos (fuente canónica) |
| `public/datos/rio.datos.js` | El mismo contenido como `window.RIO_DATOS` |
| `public/fuentes/` | Tipografías woff2 (licencia SIL OFL) |
| `next.config.mjs` | Sirve `public/index.html` en la raíz `/` |
| `app/layout.js` | Layout mínimo que Next.js exige |
| `AGENTS.md` | Reglas del proyecto para v0 y otros agentes |

## Probarlo en tu computadora

```
npm install
npm run dev     # http://localhost:3000
```

## Actualizar los datos

Desde la carpeta `codigo/` del proyecto de investigación:

```
python3 exportar_sitio.py Impuestos_historicos_Mexico_v0.2.xlsx ../sitio/datos
```

Copia `rio.json` y `rio.datos.js` resultantes a `public/datos/` (en v0, súbelos al chat o haz commit en el repositorio de GitHub conectado).
