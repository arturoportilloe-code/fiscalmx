// Next.js exige un layout raíz cuando existe la carpeta app/.
// La página real es public/index.html (ver next.config.mjs); este layout
// solo se usaría para rutas nuevas de React que se agreguen después.
export const metadata = {
  title: "El río de los impuestos",
  description: "Cinco siglos de impuestos en México, de los tributos mexicas a 2026.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="es">
      <body>{children}</body>
    </html>
  );
}
