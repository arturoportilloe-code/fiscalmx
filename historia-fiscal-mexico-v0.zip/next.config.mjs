/**
 * El sitio es estático y vive en /public (index.html, css/, js/, datos/, fuentes/).
 * Next.js solo lo sirve: la raíz "/" muestra public/index.html sin cambiar la URL,
 * así que siguen funcionando "/#1790" y "/?anio=1790".
 */
/** @type {import('next').NextConfig} */
const nextConfig = {
  async rewrites() {
    return {
      beforeFiles: [{ source: "/", destination: "/index.html" }],
    };
  },
};

export default nextConfig;
