/* El río de los impuestos — lógica del sitio (sin dependencias).
   Lee window.RIO_DATOS (datos/rio.datos.js) o, si no existe, datos/rio.json.
   Reglas de conteo: ver meta.reglas en el JSON y LEEME.md. */
(function () {
  'use strict';

  var NS = 'http://www.w3.org/2000/svg';
  var A0 = 1428, A1 = 2026;
  var OSCURAS = { documentos: true, propiedad: true };
  var D, FAM, FIDX, FIRME, BLANDA, EPOCAS;
  var estado = { anio: 1790, familia: null, detalle: null, recorriendo: false };
  var geo = null;
  var el = {};

  function $(id) { return document.getElementById(id); }
  function svgEl(tag, attrs, parent) {
    var n = document.createElementNS(NS, tag);
    for (var k in attrs) { if (attrs[k] !== undefined && attrs[k] !== null) n.setAttribute(k, attrs[k]); }
    if (parent) parent.appendChild(n);
    return n;
  }
  function color(f) { return 'var(' + f.color + ')'; }

  /* ---------- Escala de tiempo por tramos ---------- */
  function rel(anio) {
    var e = D.escala;
    if (anio <= e[0][0]) return 0;
    for (var i = 0; i < e.length - 1; i++) {
      if (anio <= e[i + 1][0]) return e[i][1] + (anio - e[i][0]) / (e[i + 1][0] - e[i][0]) * (e[i + 1][1] - e[i][1]);
    }
    return e[e.length - 1][1];
  }
  function anioDeRel(p) {
    var e = D.escala;
    if (p <= 0) return e[0][0];
    for (var i = 0; i < e.length - 1; i++) {
      if (p <= e[i + 1][1]) return e[i][0] + (p - e[i][1]) / (e[i + 1][1] - e[i][1]) * (e[i + 1][0] - e[i][0]);
    }
    return e[e.length - 1][0];
  }
  function tDeAnio(anio) { return geo.t0 + rel(anio) / 1500 * (geo.t1 - geo.t0); }
  function anioDeT(t) { return anioDeRel((t - geo.t0) / (geo.t1 - geo.t0) * 1500); }

  /* ---------- Conteos por año ---------- */
  function estadoEn(o, y) {
    if (o.inicio[1] <= y && y <= o.fin[0]) return 'firme';
    if ((o.inicio[0] <= y && y < o.inicio[1]) || (o.fin[0] < y && y <= o.fin[1])) return 'blanda';
    return null;
  }
  function prepararConteos() {
    var n = A1 - A0 + 1;
    FIRME = []; BLANDA = [];
    for (var f = 0; f < FAM.length; f++) { FIRME.push(new Float32Array(n)); BLANDA.push(new Float32Array(n)); }
    D.obligaciones.forEach(function (o) {
      var fi = FIDX[o.familia];
      for (var y = A0; y <= A1; y++) {
        var s = estadoEn(o, y);
        if (s === 'firme') FIRME[fi][y - A0] += 1;
        else if (s === 'blanda') BLANDA[fi][y - A0] += 1;
      }
    });
  }
  function vigentes(y) {
    var lista = [];
    D.obligaciones.forEach(function (o) {
      var s = estadoEn(o, y);
      if (s) lista.push({ o: o, blanda: s === 'blanda' });
    });
    lista.sort(function (a, b) { return (FIDX[a.o.familia] - FIDX[b.o.familia]) || (a.o.inicio[0] - b.o.inicio[0]); });
    return lista;
  }
  function epocaDe(y) {
    var r = EPOCAS[0];
    EPOCAS.forEach(function (e) { if (e.inicio <= y) r = e; });
    return r;
  }

  /* ---------- Geometría ---------- */
  function medir() {
    var ancho = el.lienzo.clientWidth || 360;
    var movil = window.matchMedia('(max-width: 759px)').matches;
    if (!movil) {
      var alto = Math.round(Math.max(400, Math.min(520, ancho * 0.34)));
      return { movil: false, W: ancho, H: alto, t0: 14, t1: ancho - 14, c0: 112, c1: alto - 70, ejeC: alto - 56, cobC: alto - 20 };
    }
    var largo = Math.round(Math.max(1700, Math.min(2600, window.innerHeight * 2.6)));
    var colIzq = Math.round(Math.min(150, ancho * 0.4));
    return { movil: true, W: ancho, H: largo + 60, t0: 24, t1: largo + 24, c0: colIzq + 10, c1: ancho - 2, ejeC: colIzq - 6, cobC: 0, colIzq: colIzq };
  }
  function P(t, c) { return geo.movil ? [c, t] : [t, c]; }

  function suavizar(vals, sigmaMuestras) {
    var n = vals.length, r = new Float32Array(n), rad = Math.ceil(sigmaMuestras * 3), w = [], i, j;
    for (j = -rad; j <= rad; j++) w.push(Math.exp(-(j * j) / (2 * sigmaMuestras * sigmaMuestras)));
    for (i = 0; i < n; i++) {
      var s = 0, ws = 0;
      for (j = -rad; j <= rad; j++) {
        var k = i + j;
        if (k < 0 || k >= n) continue;
        s += vals[k] * w[j + rad]; ws += w[j + rad];
      }
      r[i] = s / ws;
    }
    return r;
  }

  function construirRio() {
    var paso = 3, ts = [], t;
    for (t = geo.t0; t <= geo.t1; t += paso) ts.push(t);
    if (ts[ts.length - 1] < geo.t1) ts.push(geo.t1);
    var anios = ts.map(function (tt) { return Math.max(A0, Math.min(A1, Math.floor(anioDeT(tt) + 1e-6))); });
    var sigma = (geo.movil ? 10 : Math.max(6, (geo.t1 - geo.t0) / 200)) / paso;
    var capas = [];
    FAM.forEach(function (f, fi) {
      var fz = suavizar(anios.map(function (y) { return FIRME[fi][y - A0]; }), sigma);
      var bl = suavizar(anios.map(function (y) { return BLANDA[fi][y - A0]; }), sigma);
      capas.push({ f: f, firme: fz, blanda: bl });
    });
    var total = ts.map(function (_, i) { var s = 0; capas.forEach(function (c) { s += c.firme[i] + c.blanda[i]; }); return s; });
    var maxT = Math.max.apply(null, total) || 1;
    var U = (geo.c1 - geo.c0) * 0.94 / maxT;
    var cc = (geo.c0 + geo.c1) / 2;
    var cur = total.map(function (s) { return cc - s * U / 2; });
    capas.forEach(function (c) {
      c.sup = cur.slice();
      c.medio = cur.map(function (v, i) { return v + c.firme[i] * U; });
      c.inf = c.medio.map(function (v, i) { return v + c.blanda[i] * U; });
      cur = c.inf.slice();
    });
    return { ts: ts, capas: capas, U: U, envSup: total.map(function (s) { return cc - s * U / 2; }), envInf: total.map(function (s) { return cc + s * U / 2; }) };
  }

  function curva(pts) {
    if (pts.length < 2) return '';
    var d = 'M' + pts[0][0].toFixed(1) + ' ' + pts[0][1].toFixed(1);
    for (var i = 0; i < pts.length - 1; i++) {
      var p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2;
      var c1x = p1[0] + (p2[0] - p0[0]) / 6, c1y = p1[1] + (p2[1] - p0[1]) / 6;
      var c2x = p2[0] - (p3[0] - p1[0]) / 6, c2y = p2[1] - (p3[1] - p1[1]) / 6;
      d += 'C' + c1x.toFixed(1) + ' ' + c1y.toFixed(1) + ' ' + c2x.toFixed(1) + ' ' + c2y.toFixed(1) + ' ' + p2[0].toFixed(1) + ' ' + p2[1].toFixed(1);
    }
    return d;
  }
  function trazoBanda(ts, sup, inf) {
    var ida = [], vuelta = [], hay = false;
    for (var i = 0; i < ts.length; i += 2) {
      if (inf[i] - sup[i] > 0.05) hay = true;
      ida.push(P(ts[i], sup[i])); vuelta.push(P(ts[i], inf[i]));
    }
    var u = ts.length - 1;
    if (u % 2) { ida.push(P(ts[u], sup[u])); vuelta.push(P(ts[u], inf[u])); }
    if (!hay) return null;
    vuelta.reverse();
    var a = curva(ida), b = curva(vuelta);
    return a + 'L' + b.slice(1) + 'Z';
  }

  /* ---------- Dibujo ---------- */
  function dibujar() {
    geo = medir();
    var rio = construirRio();
    geo.rio = rio;
    el.lienzo.querySelectorAll('svg').forEach(function (n) { n.remove(); });
    var svg = svgEl('svg', { viewBox: '0 0 ' + geo.W + ' ' + geo.H, width: geo.W, height: geo.H, role: 'img',
      'aria-label': 'Río de impuestos por familia, de 1428 a 2026. Use el control de año o la tabla de datos para leer los valores.' }, el.lienzo);
    el.svg = svg;
    var defs = svgEl('defs', {}, svg);
    FAM.forEach(function (f) {
      var p = svgEl('pattern', { id: 'trama-' + f.id, width: 6, height: 6, patternUnits: 'userSpaceOnUse', patternTransform: 'rotate(45)' }, defs);
      svgEl('rect', { width: 6, height: 6, style: 'fill: color-mix(in srgb, ' + color(f) + ' 55%, var(--fondo))' }, p);
      svgEl('line', { x1: 0, y1: 0, x2: 0, y2: 6, style: 'stroke: ' + color(f) + '; stroke-width: 3' }, p);
    });
    var pc = svgEl('pattern', { id: 'trama-cobertura', width: 4, height: 4, patternUnits: 'userSpaceOnUse', patternTransform: 'rotate(45)' }, defs);
    svgEl('line', { x1: 0, y1: 0, x2: 0, y2: 4, style: 'stroke: var(--tenue); stroke-width: 1.2' }, pc);
    var brillo = svgEl('linearGradient', { id: 'haz', x1: geo.movil ? 0 : 0, y1: geo.movil ? 0 : 0, x2: geo.movil ? 0 : 1, y2: geo.movil ? 1 : 0 }, defs);
    svgEl('stop', { offset: 0, style: 'stop-color: var(--acento); stop-opacity: 0' }, brillo);
    svgEl('stop', { offset: 0.5, style: 'stop-color: var(--acento); stop-opacity: .25' }, brillo);
    svgEl('stop', { offset: 1, style: 'stop-color: var(--acento); stop-opacity: 0' }, brillo);

    // Franja de cobertura y marcas de años
    var gEje = svgEl('g', {}, svg);
    EPOCAS.forEach(function (e) {
      var a = Math.max(A0, e.inicio), b = Math.min(A1, e.fin);
      if (b <= a) return;
      var ta = tDeAnio(a), tb = tDeAnio(b);
      var r = geo.movil ? { x: 0, y: ta + 1, width: 7, height: Math.max(1, tb - ta - 2) } : { x: ta + 1, y: geo.cobC, width: Math.max(1, tb - ta - 2), height: 8 };
      var rect = svgEl('rect', Object.assign({ class: 'cobertura-' + e.nivel, rx: 1 }, r), gEje);
      var tt = svgEl('title', {}, rect);
      tt.textContent = e.nombre + ' (' + e.inicio + '-' + e.fin + '): cobertura ' + e.nivel + '. ' + e.criterio;
    });
    var marcas = [1500, 1600, 1700, 1800, 1850, 1900, 1950, 2000];
    marcas.forEach(function (y) {
      var t = tDeAnio(y);
      if (geo.movil) {
        svgEl('line', { x1: geo.ejeC - 6, y1: t, x2: geo.ejeC, y2: t, style: 'stroke: var(--tenue); stroke-width: 1' }, gEje);
        svgEl('text', { x: geo.ejeC - 10, y: t + 4, 'text-anchor': 'end', class: 'marca' }, gEje).textContent = y;
      } else {
        svgEl('line', { x1: t, y1: geo.ejeC - 8, x2: t, y2: geo.ejeC, style: 'stroke: var(--tenue); stroke-width: 1' }, gEje);
        svgEl('text', { x: t, y: geo.ejeC + 14, 'text-anchor': 'middle', class: 'marca' }, gEje).textContent = y;
      }
    });
    var tHoy = tDeAnio(A1);
    if (geo.movil) {
      svgEl('text', { x: geo.ejeC - 10, y: tHoy + 4, 'text-anchor': 'end', class: 'marca', style: 'fill: var(--acento)' }, gEje).textContent = 'HOY';
      svgEl('text', { x: geo.ejeC - 10, y: tDeAnio(A0) + 4, 'text-anchor': 'end', class: 'marca' }, gEje).textContent = A0;
    } else {
      svgEl('text', { x: tHoy, y: geo.ejeC + 14, 'text-anchor': 'end', class: 'marca', style: 'fill: var(--acento)' }, gEje).textContent = 'HOY';
    }

    // Corrientes
    var gRio = svgEl('g', {}, svg);
    el.bandas = {};
    rio.capas.forEach(function (c) {
      var g = svgEl('g', { 'data-familia': c.f.id }, gRio);
      var dF = trazoBanda(rio.ts, c.sup, c.medio), dB = trazoBanda(rio.ts, c.medio, c.inf);
      if (dF) svgEl('path', { d: dF, class: 'banda firme', style: 'fill: ' + color(c.f) }, g);
      if (dB) svgEl('path', { d: dB, class: 'banda blanda', style: 'fill: url(#trama-' + c.f.id + ')' }, g);
      var tt = svgEl('title', {}, g);
      tt.textContent = c.f.nombre;
      el.bandas[c.f.id] = g;
    });

    // Etiquetas de carril (solo escritorio)
    if (!geo.movil) {
      var gEt = svgEl('g', {}, svg);
      rio.capas.forEach(function (c) {
        var anchoTxt = c.f.corto.length * 7.6 + 18, medio = Math.ceil(anchoTxt / 2 / 3), mejor = null;
        for (var i = medio; i < rio.ts.length - medio; i++) {
          var sup = -1e9, inf = 1e9;
          for (var j = i - medio; j <= i + medio; j++) { sup = Math.max(sup, c.sup[j]); inf = Math.min(inf, c.medio[j]); }
          if (!mejor || inf - sup > mejor.h) mejor = { h: inf - sup, i: i, c: (sup + inf) / 2 };
        }
        if (!mejor || mejor.h < 15) return;
        var txt = svgEl('text', { x: rio.ts[mejor.i], y: mejor.c + 4, 'text-anchor': 'middle', class: 'etiqueta-carril',
          'data-familia': c.f.id, style: 'fill: ' + (OSCURAS[c.f.id] ? 'var(--texto)' : 'var(--fondo)') }, gEt);
        txt.textContent = c.f.corto;
      });
    }

    // Hitos
    var gH = svgEl('g', {}, svg);
    D.hitos.forEach(function (h, k) {
      var t = tDeAnio(h.anio), i = Math.round((t - geo.t0) / 3);
      i = Math.max(0, Math.min(rio.ts.length - 1, i));
      if (geo.movil) {
        var bordeIzq = rio.envSup[i];
        svgEl('line', { x1: geo.ejeC + 2, y1: t, x2: bordeIzq, y2: t, style: 'stroke: var(--texto); stroke-width: 1; stroke-dasharray: 2 4; opacity: .5' }, gH);
        svgEl('circle', { cx: bordeIzq, cy: t, r: 3, style: 'fill: var(--texto)' }, gH);
        var ty = t - 22 < 18 ? t + 16 : t - 8;
        svgEl('text', { x: geo.ejeC + 4, y: ty - 14, class: 'hito-anio' }, gH).textContent = h.anio;
        wrapTexto(svgEl('text', { x: geo.ejeC + 4, y: ty, class: 'hito-texto', style: 'font-size: 12.5px' }, gH), h.texto, Math.max(70, bordeIzq - geo.ejeC - 12), 15);
      } else {
        var nivel = k % 2 === 0 ? 4 : 50;
        var top = rio.envSup[i];
        svgEl('line', { x1: t, y1: nivel + 40, x2: t, y2: top, style: 'stroke: var(--texto); stroke-width: 1; stroke-dasharray: 2 4; opacity: .45' }, gH);
        svgEl('circle', { cx: t, cy: top, r: 3, style: 'fill: var(--texto)' }, gH);
        svgEl('line', { x1: t, y1: nivel, x2: t, y2: nivel + 36, style: 'stroke: var(--acento); stroke-width: 2' }, gH);
        var alDerecha = t < geo.W - 230;
        svgEl('text', { x: alDerecha ? t + 10 : t - 10, y: nivel + 12, 'text-anchor': alDerecha ? 'start' : 'end', class: 'hito-anio' }, gH).textContent = h.anio;
        svgEl('text', { x: alDerecha ? t + 10 : t - 10, y: nivel + 31, 'text-anchor': alDerecha ? 'start' : 'end', class: 'hito-texto' }, gH).textContent = h.texto;
      }
    });

    // Lente
    var gL = svgEl('g', { 'pointer-events': 'none' }, svg);
    el.lenteHaz = svgEl('rect', { style: 'fill: url(#haz)' }, gL);
    el.lenteLinea = svgEl('line', { style: 'stroke: var(--texto); stroke-width: 1.5' }, gL);
    el.lentePastilla = svgEl('rect', { rx: 12, width: 64, height: 24, style: 'fill: var(--acento)' }, gL);
    el.lenteTexto = svgEl('text', { 'text-anchor': 'middle', style: 'font-family: var(--f-mono); font-size: 13px; font-weight: 500; fill: var(--sobre-acento)' }, gL);

    // Interacción con el lienzo
    activarLienzo(svg);
    pintarFamilia();
    actualizarLente();
  }

  function wrapTexto(nodo, texto, ancho, alto) {
    var palabras = texto.split(' '), linea = '', lineas = [];
    var porLetra = 7.4;
    palabras.forEach(function (p) {
      var prueba = linea ? linea + ' ' + p : p;
      if (prueba.length * porLetra > ancho && linea) { lineas.push(linea); linea = p; } else linea = prueba;
    });
    if (linea) lineas.push(linea);
    var x = nodo.getAttribute('x');
    lineas.forEach(function (l, i) {
      var ts = svgEl('tspan', { x: x, dy: i === 0 ? 0 : alto }, nodo);
      ts.textContent = l;
    });
  }

  function actualizarLente() {
    if (!geo) return;
    var t = tDeAnio(estado.anio), i = Math.round((t - geo.t0) / 3);
    i = Math.max(0, Math.min(geo.rio.ts.length - 1, i));
    var sup = geo.rio.envSup[i], inf = geo.rio.envInf[i];
    if (geo.movil) {
      var izq = geo.ejeC + 2;
      set(el.lenteHaz, { x: izq, y: t - 16, width: geo.W - izq, height: 32 });
      set(el.lenteLinea, { x1: izq, y1: t, x2: geo.W, y2: t });
      set(el.lentePastilla, { x: Math.max(0, geo.ejeC - 66), y: t - 12 });
      set(el.lenteTexto, { x: Math.max(32, geo.ejeC - 34), y: t + 5 });
    } else {
      var arriba = Math.max(geo.c0 - 8, sup - 10);
      set(el.lenteHaz, { x: t - 18, y: arriba, width: 36, height: geo.ejeC - arriba });
      set(el.lenteLinea, { x1: t, y1: arriba, x2: t, y2: geo.ejeC });
      var px = Math.max(0, Math.min(geo.W - 64, t - 32));
      set(el.lentePastilla, { x: px, y: arriba - 28 });
      set(el.lenteTexto, { x: px + 32, y: arriba - 11 });
    }
    el.lenteTexto.textContent = estado.anio;
  }
  function set(n, a) { for (var k in a) n.setAttribute(k, a[k]); }

  /* ---------- Interacción ---------- */
  function activarLienzo(svg) {
    var arrastre = null;
    function anioDePuntero(ev) {
      var r = svg.getBoundingClientRect();
      var esc = geo.W / r.width;
      var t = geo.movil ? (ev.clientY - r.top) * (geo.H / r.height) : (ev.clientX - r.left) * esc;
      return Math.round(anioDeT(Math.max(geo.t0, Math.min(geo.t1, t))));
    }
    svg.addEventListener('pointerdown', function (ev) {
      if (geo.movil) return;
      arrastre = { x: ev.clientX, movido: false };
      svg.setPointerCapture && svg.setPointerCapture(ev.pointerId);
    });
    svg.addEventListener('pointermove', function (ev) {
      if (!arrastre) return;
      if (Math.abs(ev.clientX - arrastre.x) > 4) arrastre.movido = true;
      if (arrastre.movido) fijarAnio(anioDePuntero(ev), 'arrastre');
    });
    svg.addEventListener('pointerup', function (ev) {
      if (geo.movil) {
        var g = ev.target.closest && ev.target.closest('[data-familia]');
        if (g) alternarFamilia(g.getAttribute('data-familia'));
        return;
      }
      if (!arrastre) return;
      var movido = arrastre.movido; arrastre = null;
      if (movido) return;
      var grupo = ev.target.closest && ev.target.closest('g[data-familia]');
      if (grupo) alternarFamilia(grupo.getAttribute('data-familia'));
      fijarAnio(anioDePuntero(ev), 'clic');
    });
    svg.addEventListener('pointercancel', function () { arrastre = null; });
  }

  function alternarFamilia(id) {
    estado.familia = estado.familia === id ? null : id;
    pintarFamilia();
    pintarLectura();
  }
  function pintarFamilia() {
    FAM.forEach(function (f) {
      var on = !estado.familia || estado.familia === f.id;
      if (el.bandas && el.bandas[f.id]) el.bandas[f.id].style.opacity = on ? 1 : 0.14;
      var b = el.botonesFam && el.botonesFam[f.id];
      if (b) b.setAttribute('aria-pressed', estado.familia === f.id ? 'true' : 'false');
    });
    if (el.svg) el.svg.querySelectorAll('.etiqueta-carril').forEach(function (t) {
      t.style.opacity = (!estado.familia || estado.familia === t.getAttribute('data-familia')) ? 1 : 0.2;
    });
  }

  var hashTimer = null;
  function fijarAnio(y, origen) {
    y = Math.max(A0, Math.min(A1, Math.round(y)));
    if (y === estado.anio && origen !== 'inicio') return;
    estado.anio = y;
    actualizarLente();
    pintarLectura();
    if (origen !== 'rango') sincronizarRango();
    clearTimeout(hashTimer);
    hashTimer = setTimeout(function () {
      try { history.replaceState(null, '', '#' + y); } catch (e) { /* sin historial disponible */ }
    }, 250);
  }
  function sincronizarRango() {
    if (!geo || geo.movil) return;
    var v = Math.round((tDeAnio(estado.anio) - geo.t0) / (geo.t1 - geo.t0) * 1000);
    el.rango.value = v;
    el.rango.setAttribute('aria-valuetext', String(estado.anio));
    el.avance.style.width = (v / 10) + '%';
  }

  function textoNivel(n) {
    return n === 'alta' ? 'Periodo bien documentado' : n === 'media' ? 'Periodo documentado en parte' : 'Periodo con huecos importantes';
  }
  function pintarLectura() {
    var y = estado.anio, ep = epocaDe(y);
    el.anio.textContent = y;
    el.epocaNombre.textContent = ep.nombre;
    el.nivel.setAttribute('data-nivel', ep.nivel);
    el.nivel.textContent = textoNivel(ep.nivel);
    el.nivelCriterio.textContent = ep.criterio;
    if (el.epocaGrande.textContent !== ep.corto) el.epocaGrande.textContent = ep.corto;

    var todas = vigentes(y);
    var lista = estado.familia ? todas.filter(function (v) { return v.o.familia === estado.familia; }) : todas;
    var nB = lista.filter(function (v) { return v.blanda; }).length;
    var n = lista.length;
    el.conteo.textContent = n === 0 ? 'Ninguna obligación documentada' : n === 1 ? '1 obligación documentada' : n + ' obligaciones documentadas';
    el.conteoBlando.textContent = nB ? (nB === 1 ? '1 con fechas inciertas' : nB + ' con fechas inciertas') : '';
    el.abrirLista.textContent = el.lectura.classList.contains('abierta') ? 'Ocultar la lista' : 'Ver la lista';

    if (estado.familia) {
      var f = FAM[FIDX[estado.familia]];
      el.filtro.hidden = false;
      el.filtro.innerHTML = '';
      var dot = document.createElement('span'); dot.className = 'punto'; dot.style.background = color(f);
      el.filtro.appendChild(dot);
      el.filtro.appendChild(document.createTextNode('Solo ' + f.nombre.toLowerCase() + ' · ver todas'));
    } else el.filtro.hidden = true;

    el.fichas.innerHTML = '';
    if (!n) {
      var li0 = document.createElement('li'); li0.className = 'vacio';
      li0.textContent = estado.familia ? 'No hay obligaciones de esta familia documentadas en este año.' : 'No hay obligaciones documentadas en este año.';
      el.fichas.appendChild(li0);
    }
    lista.forEach(function (v) {
      var li = document.createElement('li');
      var b = document.createElement('button');
      b.type = 'button'; b.className = 'ficha';
      b.setAttribute('data-blanda', v.blanda ? 'true' : 'false');
      b.setAttribute('aria-pressed', estado.detalle === v.o.id ? 'true' : 'false');
      b.title = v.o.periodo;
      var dot = document.createElement('span'); dot.className = 'punto'; dot.style.background = color(FAM[FIDX[v.o.familia]]);
      b.appendChild(dot);
      b.appendChild(document.createTextNode(v.o.corto));
      if (v.blanda) { var sr = document.createElement('span'); sr.className = 'sr'; sr.style.cssText = 'position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0)'; sr.textContent = ' (fecha incierta)'; b.appendChild(sr); }
      b.addEventListener('click', function () { mostrarDetalle(v.o.id); });
      li.appendChild(b); el.fichas.appendChild(li);
    });
    if (estado.detalle && !lista.some(function (v) { return v.o.id === estado.detalle; })) ocultarDetalle();
  }

  function mostrarDetalle(id) {
    var o = D.obligaciones.find(function (x) { return x.id === id; });
    if (!o) return;
    estado.detalle = id;
    el.detalleNombre.textContent = o.nombre;
    el.detallePeriodo.textContent = o.periodo;
    el.detalleExplicacion.textContent = o.explicacion;
    el.detalleDatos.innerHTML = '';
    var filas = [['Familia', FAM[FIDX[o.familia]].nombre], ['Tarifa', o.tarifa], ['Quién pagaba', o.paga], ['Quién recibía', o.recibe],
      ['Jurisdicción', o.jurisdiccion], ['Certeza', o.certeza + ' · ' + o.verificacion], ['Fuentes', o.fuentes]];
    filas.forEach(function (f) {
      if (!f[1]) return;
      var dt = document.createElement('dt'); dt.textContent = f[0];
      var dd = document.createElement('dd'); dd.textContent = f[1];
      el.detalleDatos.appendChild(dt); el.detalleDatos.appendChild(dd);
    });
    el.detalle.hidden = false;
    el.fichas.querySelectorAll('.ficha').forEach(function (b) { b.setAttribute('aria-pressed', 'false'); });
    pintarLectura();
  }
  function ocultarDetalle() { estado.detalle = null; el.detalle.hidden = true; }

  /* ---------- Recorrido automático (escritorio) ---------- */
  var rafId = null;
  function alternarRecorrido() {
    if (estado.recorriendo) { detener(); return; }
    estado.recorriendo = true;
    el.iconoRecorrer.innerHTML = '<rect x="3" y="2" width="3.5" height="12" rx="1"></rect><rect x="9.5" y="2" width="3.5" height="12" rx="1"></rect>';
    el.recorrer.setAttribute('aria-label', 'Pausar el recorrido');
    var t = tDeAnio(estado.anio >= A1 - 1 ? A0 : estado.anio), ultimo = null;
    var velocidad = (geo.t1 - geo.t0) / 22000; // px por milisegundo: unos 22 s de punta a punta
    function cuadro(ahora) {
      if (!estado.recorriendo) return;
      if (ultimo !== null) t += (ahora - ultimo) * velocidad;
      ultimo = ahora;
      if (t >= geo.t1) { fijarAnio(A1, 'recorrido'); detener(); return; }
      fijarAnio(anioDeT(t), 'recorrido');
      rafId = requestAnimationFrame(cuadro);
    }
    rafId = requestAnimationFrame(cuadro);
  }
  function detener() {
    estado.recorriendo = false;
    if (rafId) cancelAnimationFrame(rafId);
    el.iconoRecorrer.innerHTML = '<path d="M4 2 L14 8 L4 14 Z"></path>';
    el.recorrer.setAttribute('aria-label', 'Recorrer de 1428 a 2026');
  }

  /* ---------- Celular: el año sigue al desplazamiento ---------- */
  var desplTick = false;
  function alDesplazar() {
    if (!geo || !geo.movil || desplTick) return;
    desplTick = true;
    requestAnimationFrame(function () {
      desplTick = false;
      var r = el.svg.getBoundingClientRect();
      var alturaLectura = el.lectura.getBoundingClientRect().height;
      var centro = (window.innerHeight - alturaLectura) * 0.5;
      var t = (centro - r.top) * (geo.H / r.height);
      if (t < geo.t0 - 40 || t > geo.t1 + 40) return;
      fijarAnio(anioDeT(Math.max(geo.t0, Math.min(geo.t1, t))), 'desplazamiento');
    });
  }

  /* ---------- Secciones estáticas ---------- */
  function pintarLeyenda() {
    el.botonesFam = {};
    FAM.forEach(function (f) {
      var b = document.createElement('button');
      b.type = 'button'; b.className = 'familia'; b.setAttribute('aria-pressed', 'false');
      var dot = document.createElement('span'); dot.className = 'punto'; dot.style.background = color(f);
      b.appendChild(dot); b.appendChild(document.createTextNode(f.nombre));
      b.addEventListener('click', function () { alternarFamilia(f.id); });
      el.familias.appendChild(b);
      el.botonesFam[f.id] = b;
    });
  }
  function pintarHuecos() {
    EPOCAS.filter(function (e) { return e.nivel !== 'alta'; })
      .sort(function (a, b) { return (a.nivel === 'baja' ? 0 : 1) - (b.nivel === 'baja' ? 0 : 1) || a.inicio - b.inicio; })
      .forEach(function (e) {
        var li = document.createElement('li');
        li.innerHTML = '<span class="rango"></span><span class="que"><b></b><span></span></span>';
        li.querySelector('.rango').textContent = e.inicio + '-' + e.fin;
        li.querySelector('b').textContent = e.nombre + ' · ' + textoNivel(e.nivel).toLowerCase();
        li.querySelector('.que span').textContent = 'Falta: ' + e.faltantes;
        el.huecos.appendChild(li);
      });
  }
  function pintarTabla() {
    var filas = D.obligaciones.slice().sort(function (a, b) { return a.inicio[0] - b.inicio[0] || FIDX[a.familia] - FIDX[b.familia]; });
    var frag = document.createDocumentFragment();
    filas.forEach(function (o) {
      var tr = document.createElement('tr');
      [o.nombre, FAM[FIDX[o.familia]].corto, o.periodo, o.certeza + ' · ' + o.verificacion, o.fuentes].forEach(function (v, i) {
        var td = document.createElement('td'); td.textContent = v; if (i === 2) td.className = 'num'; tr.appendChild(td);
      });
      frag.appendChild(tr);
    });
    el.tabla.appendChild(frag);
    el.resumenTabla.textContent = 'Ver la tabla de ' + filas.length + ' obligaciones';
    el.pie.textContent = 'Datos: versión ' + D.meta.version + ' del libro de investigación, con corte al ' + fechaLarga(D.meta.fecha_corte) + '. ' +
      D.meta.n_obligaciones + ' versiones de impuestos y ' + D.meta.n_fuentes + ' fuentes.';
  }
  function fechaLarga(iso) {
    var m = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
    var p = iso.split('-');
    return parseInt(p[2], 10) + ' de ' + m[parseInt(p[1], 10) - 1] + ' de ' + p[0];
  }

  /* ---------- Arranque ---------- */
  function anioInicial() {
    var h = (location.hash || '').replace('#', '');
    var q = (location.search.match(/[?&]anio=(\d{4})/) || [])[1];
    var y = parseInt(/^\d{4}$/.test(h) ? h : (q || '1790'), 10);
    return isNaN(y) ? 1790 : Math.max(A0, Math.min(A1, y));
  }
  function iniciar(datos) {
    D = datos;
    FAM = D.familias; FIDX = {}; FAM.forEach(function (f, i) { FIDX[f.id] = i; });
    EPOCAS = D.epocas;
    ['lienzo', 'anio', 'epocaNombre', 'nivel', 'nivelCriterio', 'conteo', 'conteoBlando', 'filtro', 'abrirLista', 'fichas', 'detalle',
      'detalleNombre', 'detallePeriodo', 'detalleExplicacion', 'detalleDatos', 'cerrarDetalle', 'familias', 'huecos', 'lectura',
      'recorrer', 'iconoRecorrer', 'epocaGrande'].forEach(function (k) { el[k] = $(k); });
    el.rango = $('anioRango'); el.avance = $('pistaAvance'); el.tabla = $('tablaCuerpo'); el.resumenTabla = $('resumenTabla'); el.pie = $('pieDatos');
    prepararConteos();
    pintarLeyenda(); pintarHuecos(); pintarTabla();
    estado.anio = anioInicial();
    dibujar();
    fijarAnio(estado.anio, 'inicio');
    sincronizarRango();

    el.rango.addEventListener('input', function () {
      detener();
      var t = geo.t0 + el.rango.value / 1000 * (geo.t1 - geo.t0);
      el.avance.style.width = (el.rango.value / 10) + '%';
      fijarAnio(anioDeT(t), 'rango');
      el.rango.setAttribute('aria-valuetext', String(estado.anio));
    });
    el.rango.addEventListener('keydown', function (ev) {
      var d = { ArrowRight: 1, ArrowUp: 1, ArrowLeft: -1, ArrowDown: -1, PageUp: 10, PageDown: -10 }[ev.key];
      if (ev.key === 'Home') d = A0 - estado.anio; else if (ev.key === 'End') d = A1 - estado.anio;
      if (d === undefined) return;
      ev.preventDefault(); detener();
      fijarAnio(estado.anio + d, 'teclado');
    });
    el.recorrer.addEventListener('click', alternarRecorrido);
    el.filtro.addEventListener('click', function () { estado.familia = null; pintarFamilia(); pintarLectura(); });
    el.cerrarDetalle.addEventListener('click', function () { ocultarDetalle(); pintarLectura(); });
    el.abrirLista.addEventListener('click', function () {
      var ab = el.lectura.classList.toggle('abierta');
      el.abrirLista.setAttribute('aria-expanded', ab ? 'true' : 'false');
      el.abrirLista.textContent = ab ? 'Ocultar la lista' : 'Ver la lista';
    });
    window.addEventListener('scroll', alDesplazar, { passive: true });
    window.addEventListener('hashchange', function () {
      var h = (location.hash || '').replace('#', '');
      if (/^\d{4}$/.test(h)) fijarAnio(parseInt(h, 10), 'hash');
    });
    var ancho = el.lienzo.clientWidth, timer = null;
    window.addEventListener('resize', function () {
      clearTimeout(timer);
      timer = setTimeout(function () {
        if (Math.abs(el.lienzo.clientWidth - ancho) < 2 && geo && geo.movil === window.matchMedia('(max-width: 759px)').matches) return;
        ancho = el.lienzo.clientWidth; dibujar(); sincronizarRango();
      }, 150);
    });
    window.__rio = { estado: estado, vigentes: vigentes, conteo: function (y) { var v = vigentes(y); return [v.filter(function (x) { return !x.blanda; }).length, v.filter(function (x) { return x.blanda; }).length]; }, fijarAnio: fijarAnio };
  }

  if (window.RIO_DATOS) iniciar(window.RIO_DATOS);
  else fetch('datos/rio.json').then(function (r) { return r.json(); }).then(iniciar).catch(function () {
    var p = document.createElement('p');
    p.textContent = 'No se pudieron cargar los datos del río. Recarga la página para intentarlo de nuevo.';
    document.getElementById('lienzo').appendChild(p);
  });
})();
